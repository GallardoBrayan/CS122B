import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.*;
import java.util.*;



public class Login extends HttpServlet {
  public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
    {
      //Implement login controller to call model and make sure it can sucessfully get user and pass
      //If successfull, then add to session oand then bring them to search page

    	//get username
    	response.setContentType("text/html");
    	request.getSession(true);
        PrintWriter out = response.getWriter();
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");

    	System.out.println("email is " + email);
    	System.out.println("password is " + password);
    	Authentication auth = new Authentication();
    	try {
    		if(auth.login_authentication(email, password))
    		{
    			User u = new User(email);
    			request.getSession().setAttribute("user", u);
    			//RequestDispatcher rd = request.getRequestDispatcher("/main_V.jsp");
    			//rd.forward(request, response);
    			response.sendRedirect("/test/main_v.jsp");
    		}
    		else
    		{
    			request.setAttribute("error", "Login was incorrect");
    			RequestDispatcher rd = request.getRequestDispatcher("/index_V.jsp");
    			rd.forward(request, response);
    		}
    	}catch(Exception e)
    	{
    		System.out.println("Exception throw in Login");
    		System.out.println(e.getMessage());
    	}

    	



  }
}