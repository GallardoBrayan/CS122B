import java.util.*;


public class User
{
	public String email;

	public User(String email)
	{
		this.email = email;
	}

	public String get_email()
	{
		return email;
	}
}